from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func

class QRCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sn = db.Column(db.String(100), unique=True)
    model_id = db.Column(db.Integer, db.ForeignKey('model.id'))
    lot_no = db.Column(db.String(12), unique=True)
    lotorder_date = db.Column(db.DateTime(timezone=True))
    lotreceipt_date = db.Column(db.DateTime(timezone=True))
    lotqty = db.Column(db.Integer)
    lotcost = db.Column(db.Integer)
    begbal_stck = db.Column(db.Integer)
    store_id = db.Column(db.Integer, db.ForeignKey('store.id'))
    website_url = db.Column(db.String(100))
    distributor_id = db.Column(db.Integer, db.ForeignKey('distributor.id'))
    sale_date = db.Column(db.DateTime(timezone=True))
    endbal_stck = db.Column(db.Integer)
    qtypurchased = db.Column(db.Integer)
    warranty_period = db.Column(db.Integer)
    price = db.Column(db.Integer)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    rndgenno = db.Column(db.Integer, unique=True)
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    issued = db.Column(db.Boolean)

class Model(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    desc = db.Column(db.String(150), unique=True)
    qrcodes = db.relationship('QRCode', backref='model')

    def __repr__(self):
        return '<Model %r>' % self.id

class Store(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(25))
    phone_no = db.Column(db.String(11))
    geoloc = db.Column(db.String(50))
    village = db.Column(db.String(25))
    district_id = db.Column(db.Integer, db.ForeignKey('district.id'))
    province_id = db.Column(db.Integer, db.ForeignKey('province.id'))
    qrcodes = db.relationship('QRCode', backref='store')

class Distributor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(25))
    phone_no = db.Column(db.String(11))
    geoloc = db.Column(db.String(50))
    village = db.Column(db.String(25))
    district_id = db.Column(db.Integer, db.ForeignKey('district.id'))
    province_id = db.Column(db.Integer, db.ForeignKey('province.id'))
    qrcodes = db.relationship('QRCode', backref='distributor')

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(25))
    phone_no = db.Column(db.String(11))
    email = db.Column(db.String(150), unique=True)
    village = db.Column(db.String(25))
    district_id = db.Column(db.Integer, db.ForeignKey('district.id'))
    province_id = db.Column(db.Integer, db.ForeignKey('province.id'))
    reg_date = db.Column(db.DateTime(timezone=True))
    qrcodes = db.relationship('QRCode', backref='customer')

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    role = db.Column(db.String(1))
    qrcodes = db.relationship('QRCode', backref='user')

class District(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    province_id = db.Column(db.Integer, db.ForeignKey('province.id'))
    storecodes = db.relationship('Store', backref='district')
    distributorcodes = db.relationship('Distributor', backref='district')
    customercodes = db.relationship('Customer', backref='district')

class Province(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    distcodes = db.relationship('District', backref='province')
    storecodes = db.relationship('Store', backref='province')
    distributorcodes = db.relationship('Distributor', backref='province')
    customercodes = db.relationship('Customer', backref='province')
