$(function() {

  // test to ensure jQuery is working
  console.log("whee!")

  var province_id = 0;
  var fprovince_id = 0;

  function filterDistrict(distSelect, provID) {
    $("#" + distSelect).prop("disabled", false);
    // send value via GET to URL /<province_id>
    var get_request = $.ajax({
      type: 'GET',
      url: '/district-filter/' + provID + '/',
    });

    // handle response
    get_request.done(function(data){
      // add values to list
      var option_list = [["", "-- Select a district --"]].concat(data);
      $("#" + distSelect).empty();

      for (var i = 0; i < option_list.length; i++) {
        $("#" + distSelect).append(
          $("<option></option>").attr("value", option_list[i][0]).text(option_list[i][1]));
      }
    });

    if (provID == "") {
      $("#" + distSelect).prop("disabled", true);
    } else {
      $("#" + distSelect).prop("disabled", false);
    }

    $("#" + distSelect).val("");
  };

  $("#province_id").change(function() {
    province_id = $("#province_id").val();

    filterDistrict("district_id", province_id);
  });

  $("#fprovince_id").change(function() {
    fprovince_id = $("#fprovince_id").val();

    filterDistrict("fdistrict_id", fprovince_id);
  });

  if (fprovince_id == "") {
    $("#fdistrict_id").prop("disabled", true);
  }

});
