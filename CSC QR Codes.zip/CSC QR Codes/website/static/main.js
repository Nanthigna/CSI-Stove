$(function() {
  function parseHtmlEntities(str) {
      return str.replace(/&#([0-9]{1,4});/g, function(match, numStr) {
          var num = parseInt(numStr, 10); // read num as normal number
          return String.fromCharCode(num);
      });
  }

  function jsonHtmlDecode(str) {
    return parseHtmlEntities(str).replace(/'([^']+)':/g, '$1:');
  }
});
