function deleteQRCode(qrcodeId) {
  fetch("/delete-qrcode", {
    method: "POST",
    body: JSON.stringify({ qrcodeId: qrcodeId }),
  }).then((_res) => {
    window.location.href = "/";
  });
}
