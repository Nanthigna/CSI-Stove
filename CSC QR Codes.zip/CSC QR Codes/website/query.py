import sqlite3
import os.path

def query_db(table):
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(BASE_DIR, "csc_data.db")

    connection = sqlite3.connect(db_path)
    with connection as db:
        cur = connection.cursor()
        cur.execute("SELECT * FROM {}".format(table))
        rows = cur.fetchall()
    return rows

def cust_query_db(province_id=None, district_id=None):
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(BASE_DIR, "csc_data.db")

    connection = sqlite3.connect(db_path)
    with connection as db:
        cur = connection.cursor()
        if province_id == None:
            cur.execute("SELECT id, name, phone_no FROM customer;")
        elif district_id == None:
            cur.execute("SELECT C.id AS id, C.name AS name, C.phone_no AS phone_no, C.province_id AS provid, P.name AS provname, C.district_id AS distid, D.name AS distname FROM customer AS C INNER JOIN province AS P ON C.province_id=P.id INNER JOIN district AS D ON C.district_id=D.id WHERE C.province_id=" + str(province_id) + " ORDER BY C.district_id;")
        else:
            cur.execute("SELECT C.id AS id, C.name AS name, C.phone_no AS phone_no, C.province_id AS provid, P.name AS provname, C.district_id AS distid, D.name AS distname FROM customer AS C INNER JOIN province AS P ON C.province_id=P.id INNER JOIN district AS D ON C.district_id=D.id WHERE C.province_id=" + str(province_id) + " AND C.district_id=" + str(district_id) + ";")
        rows = cur.fetchall()
    return rows
