from flask_wtf import Form
from wtforms import SelectField


class SyncListForm(Form):
    province = SelectField(u'', choices=())
    district = SelectField(u'', choices=())
