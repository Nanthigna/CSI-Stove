from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User, Customer
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required, logout_user, current_user
from datetime import date

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email, role='A').first()
        if user:
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='success')
                login_user(user, remember=True)
                return redirect(url_for('views.qrcode'))
            else:
                flash('Incorrect credentials, try again.', category='error')
        else:
            flash('Incorrect credentials, try again.', category='error')

    return render_template("login.html", bgdecoration='login', user=current_user)


@auth.route('/logout')
@login_required
def logout():
    role = current_user.role
    logout_user()
    if role == 'A':
        return redirect(url_for('auth.login'))
    else:
        return redirect(url_for('auth.cust_login'))


@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        aut_user = User.query.filter(User.email==email, User.first_name==None, User.role=='A').first()
        user = User.query.filter(User.email==email, User.first_name!=None, User.role=='A').first()
        if user:
            flash('Email already exists.', category='error')
        elif not aut_user:
            flash('Must be first authorized by Admins.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            new_user = User(email=email, first_name=first_name, password=generate_password_hash(
                password1, method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')
            return redirect(url_for('views.qrcode'))

    return render_template("sign_up.html", bgdecoration='signup', user=current_user)


def xstr(s):
    return '' if s is None else str(s)

@auth.route('/cust_login', methods=['GET', 'POST'])
def cust_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email, role='U').first()
        print(user)
        if user:
            #user.password = xstr(user.password)
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='success')
                login_user(user, remember=True)
                return redirect(url_for('views.home'))
            else:
                flash('Incorrect credentials, try again.', category='error')
        else:
            flash('Incorrect credentials, try again.', category='error')

    return render_template("cust_login.html", bgdecoration='cust_login', user=current_user)


@auth.route('/cust_signup', methods=['GET', 'POST'])
def cust_signup():
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('userName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter(User.email==email, User.role=='U').first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(username) < 2:
            flash('User name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            new_user = User(email=email, first_name=username, password=generate_password_hash(
                password1, method='sha256'), role='U')
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')

            return redirect(url_for('views.home'))

    return render_template("cust_signup.html", bgdecoration='cust_signup', user=current_user)
