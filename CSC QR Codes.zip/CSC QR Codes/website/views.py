from flask import Blueprint, render_template, request, make_response, flash, jsonify, redirect
from flask_login import login_required, current_user
from .models import QRCode, Model, Store, Distributor, Customer, Province, District, User
from . import db
from sqlalchemy.exc import IntegrityError
from .form import SyncListForm
from .query import query_db, cust_query_db
import json
from werkzeug.security import generate_password_hash
import tkinter, tkinter.messagebox
from tkinter import filedialog
import os
from os import path
import pathlib
import wget
import sqlite3
from openpyxl import load_workbook, Workbook
from datetime import datetime
import random

views = Blueprint('views', __name__)
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@views.route('/', methods=['GET'])
def home():
    return render_template("home.html", user=current_user)

@views.route('/qrcode', methods=['GET'])
@login_required
def qrcode():
    models = Model.query.order_by(Model.id).all()
    stores = Store.query.order_by(Store.id).all()
    distributors = Distributor.query.order_by(Distributor.id).all()
    customers = Customer.query.order_by(Customer.id).all()
    provinces = Province.query.order_by(Province.id).all()
    lastID = QRCode.query.order_by(QRCode.id.desc()).first().id

    qrcodes = QRCode.query.order_by(QRCode.sn).all()
    return render_template("qrcode.html", qrcodes=qrcodes, models=models, stores=stores, distributors=distributors, customers=customers, provinces=provinces, lastID=lastID, bgdecoration='qrcode', user=current_user)


@views.route('/customer-filter/', defaults={'province_id': None, 'district_id': None}, methods=['GET'])
@views.route('/customer-filter/<int:province_id>/', defaults={'district_id': None}, methods=['GET'])
@views.route("/customer-filter/<int:province_id>/<int:district_id>/", methods=["GET"])
def get_RequestCust(province_id, district_id):
    if province_id == None:
        data = [
            (x[0], x[1], x[2]) for x in query_db("customer")]
    elif district_id == None:
        data = [
            (x[0], x[1], x[2]) for x in query_db("customer")
            if x[6] == province_id]
    else:
        data = [
            (x[0], x[1], x[2]) for x in query_db("customer")
            if (x[6] == province_id and x[5] == district_id)]

    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response

@views.route('/full-customer-filter/', defaults={'province_id': None, 'district_id': None}, methods=['GET'])
@views.route('/full-customer-filter/<int:province_id>/', defaults={'district_id': None}, methods=['GET'])
@views.route("/full-customer-filter/<int:province_id>/<int:district_id>/", methods=["GET"])
def get_RequestCustFull(province_id, district_id):
    if province_id == None:
        data = [
            (x[0], x[1], x[2]) for x in cust_query_db()]
    elif district_id == None:
        data = [
            (x[0], x[1], x[2], x[3], x[4], x[5], x[6]) for x in cust_query_db(province_id)]
    else:
        data = [
            (x[0], x[1], x[2], x[3], x[4], x[5], x[6]) for x in cust_query_db(province_id, district_id)]

    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response

@views.route('/add-qrcode/<int:model_id>/<int:store_id>/<int:customer_id>/<string:lotno>/<saledate>/<int:qtypurchased>/<int:price>/<lotorderdate>/<lotreceiptdate>/<lotqty>/<lotcost>/<begbalstck>/<distributor_id>/<warrperiod>', methods=['GET', 'POST'])
@login_required
def qrcodeAdd(model_id, store_id, customer_id, lotno, saledate, qtypurchased, price, lotorderdate, lotreceiptdate, lotqty, lotcost, begbalstck, distributor_id, warrperiod):

    saledate = datetime.strptime(saledate, '%Y-%m-%d')

    if lotorderdate == '(none)':
        lotorderdate = None
    else:
        lotorderdate = datetime.strptime(lotorderdate, '%Y-%m-%d')

    if lotreceiptdate == '(none)':
        lotreceiptdate = None
    else:
        lotreceiptdate = datetime.strptime(lotreceiptdate, '%Y-%m-%d')

    if lotqty == '(none)':
        lotqty = None

    if lotcost == '(none)':
        lotcost = None

    if begbalstck == '(none)':
        begbalstck = None

    if distributor_id == '(none)':
        distributor_id = None

    if warrperiod == '(none)':
        warrperiod = None

    lastID = QRCode.query.order_by(QRCode.id.desc()).first().id
    sn = str(lastID+1).zfill(6)
    if begbalstck == None:
        endbal_stck = None
    else:
        endbal_stck = int(begbalstck) - qtypurchased
    website_url = 'http://127.0.0.1:5000'
    # 12-bit random generated number
    rndgenno = random.randint(100000000000, 999999999999)

    new_qrcode = QRCode(sn=sn, website_url=website_url, model_id=model_id, store_id=store_id, customer_id=customer_id, lot_no=lotno, sale_date=saledate, qtypurchased=qtypurchased, price=price,
                lotorder_date=lotorderdate, lotreceipt_date=lotreceiptdate, lotqty=lotqty, lotcost=lotcost, begbal_stck=begbalstck, endbal_stck=endbal_stck, distributor_id=distributor_id, warranty_period=warrperiod, rndgenno=rndgenno, issued=0, user_id=current_user.id)

    try:
        db.session.add(new_qrcode)
        db.session.commit()
        flash('QR Code added!', category='success')
    except IntegrityError:
        db.session.rollback()
        flash('There\'s already a QR Code with this serial number!', category='error')

    return redirect('/qrcode')


@views.route('/delete-qrcode/<int:id>')
def delete_qrcode(id):
    qrcode = QRCode.query.get_or_404(id)
    if qrcode:
        if qrcode.user_id == current_user.id:
            try:
                db.session.delete(qrcode)
                db.session.commit()
                qrcodes = QRCode.query.order_by(QRCode.id).all()
                return redirect('/qrcode')
            except:
                return 'There was a problem deleting that QR code'

    return redirect('/qrcode')


@views.route("/getQRCode/<int:id>/", methods=["GET"])
def get_requestQRCode(id):
    data = [
        (x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[11], x[12], x[14], x[15], x[16], x[17]) for x in query_db("qr_code")
        if x[0] == id]
    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response


@views.route('/update-qrcode/<int:id>/<int:model_id>/<int:store_id>/<int:customer_id>/<string:lotno>/<saledate>/<int:qtypurchased>/<int:price>/<lotorderdate>/<lotreceiptdate>/<lotqty>/<lotcost>/<begbalstck>/<distributor_id>/<warrperiod>', methods=['GET', 'POST'])
@login_required
def update_qrcode(id, model_id, store_id, customer_id, lotno, saledate, qtypurchased, price, lotorderdate, lotreceiptdate, lotqty, lotcost, begbalstck, distributor_id, warrperiod):
    qrcode = QRCode.query.get_or_404(id)

    qrcode.sale_date = datetime.strptime(saledate, '%Y-%m-%d')

    if lotorderdate == '(none)':
        qrcode.lotorder_date = None
    else:
        qrcode.lotorder_date = datetime.strptime(lotorderdate, '%Y-%m-%d')

    if lotreceiptdate == '(none)':
        qrcode.lotreceipt_date = None
    else:
        qrcode.lotreceipt_date = datetime.strptime(lotreceiptdate, '%Y-%m-%d')

    if lotqty == '(none)':
        qrcode.lotqty = None
    else:
        qrcode.lotqty = lotqty

    if lotcost == '(none)':
        qrcode.lotcost = None
    else:
        qrcode.lotcost = lotcost

    if begbalstck == '(none)':
        qrcode.begbal_stck = None
    else:
        qrcode.begbal_stck = begbalstck

    if distributor_id == '(none)':
        qrcode.distributor_id = None
    else:
        qrcode.distributor_id = distributor_id

    if warrperiod == '(none)':
        qrcode.warranty_period = None
    else:
        qrcode.warranty_period = warrperiod

    if begbalstck == None:
        qrcode.endbal_stck = None
    else:
        qrcode.endbal_stck = int(begbalstck) - qtypurchased

    qrcode.model_id=model_id
    qrcode.store_id=store_id
    qrcode.customer_id=customer_id
    qrcode.lot_no=lotno
    qrcode.qtypurchased=qtypurchased
    qrcode.price=price
    qrcode.user_id=current_user.id

    try:
        db.session.commit()
        flash('QR Code successfully updated!', category='success')
    except:
        db.session.rollback()
        return 'There was an issue updating the QR code'

    return redirect('/qrcode')


@views.route('/model', methods=['GET', 'POST'])
@login_required
def model():
    if request.method == 'POST':
        model_desc = request.form['desc']

        if len(model_desc) < 2:
            flash('Description is too short!', category='error')
            return render_template('model.html', tooshort=-1, bgdecoration='model', user=current_user)
        else:
            record = Model(desc=model_desc)

            try:
                db.session.add(record)
                db.session.commit()
                models = Model.query.order_by(Model.desc).all()
                return render_template('model.html', models=models, bgdecoration='model', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a model with this description!', category='error')
                return render_template('model.html', tooshort=-1, bgdecoration='model', user=current_user)

    else:
        models = Model.query.order_by(Model.desc).all()
        return render_template('model.html', models=models, bgdecoration='model', user=current_user)


@views.route('/modelDelete/<int:id>')
def modelDelete(id):
    if not hasattr(modelDelete, "counter"):
        modelDelete.counter = 0

    if modelDelete.counter > 0:
        return redirect('/model')

    model_to_delete = Model.query.get_or_404(id)

    modelDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + model_to_delete.desc + "' model?'", 'Confirm Model Deletion')
    modelDelete.counter = 0

    if response == True:
        try:
            db.session.delete(model_to_delete)
            db.session.commit()
            models = Model.query.order_by(Model.desc).all()
            return render_template('model.html', models=models, bgdecoration='model', user=current_user)
        except:
            return 'There was a problem deleting that model'
    else:
         return redirect('/model')


@views.route('/modelUpdate/<int:id>', methods=['GET', 'POST'])
def modelUpdate(id):
    model = Model.query.get_or_404(id)

    if request.method == 'POST':
        model.desc = request.form['desc']
        models = Model.query.order_by(Model.desc).all()

        if len(model.desc) < 2:
            flash('Description is too short!', category='error')
            return render_template('modelupdate.html', model=model, bgdecoration='model', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('model.html', models=models, bgdecoration='model', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a model with this description!', category='error')
                return render_template('model.html', tooshort=-1, bgdecoration='model', user=current_user)

    else:
        return render_template('modelupdate.html', model=model, bgdecoration='model', user=current_user)


@views.route('/province', methods=['GET', 'POST'])
@login_required
def province():
    if request.method == 'POST':
        province_name = request.form['name']

        if len(province_name) < 2:
            flash('Province name is too short!', category='error')
            return render_template('province.html', tooshort=-1, bgdecoration='province', user=current_user)
        else:
            record = Province(name=province_name)

            try:
                db.session.add(record)
                db.session.commit()
                provinces = Province.query.order_by(Province.id).all()
                return render_template('province.html', provinces=provinces, bgdecoration='province', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a province with this name!', category='error')
                return render_template('province.html', tooshort=-1, provinces=provinces, bgdecoration='province', user=current_user)

    else:
        provinces = Province.query.order_by(Province.id).all()
        return render_template('province.html', provinces=provinces, bgdecoration='province', user=current_user)


@views.route('/provinceDelete/<int:id>')
def provinceDelete(id):
    if not hasattr(provinceDelete, "counter"):
        provinceDelete.counter = 0

    if provinceDelete.counter > 0:
        return redirect('/province')

    province_to_delete = Province.query.get_or_404(id)

    provinceDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + province_to_delete.name + "' province?'", 'Confirm Province Deletion')
    provinceDelete.counter = 0

    if response == True:
        try:
            db.session.delete(province_to_delete)
            db.session.commit()
            provinces = Province.query.order_by(Province.id).all()
            return render_template('province.html', provinces=provinces, bgdecoration='province', user=current_user)
        except:
            return 'There was a problem deleting that province'
    else:
         return redirect('/province')


@views.route('/provinceUpdate/<int:id>', methods=['GET', 'POST'])
def provinceUpdate(id):
    province = Province.query.get_or_404(id)

    if request.method == 'POST':
        province.name = request.form['name']
        provinces = Province.query.order_by(Province.id).all()

        if len(province.name) < 2:
            flash('Province name is too short!', category='error')
            return render_template('provinceupdate.html', province=province, bgdecoration='province', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('province.html', provinces=provinces, bgdecoration='province', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a province with this name!', category='error')
                return render_template('province.html', tooshort=-1, provinces=provinces, bgdecoration='province', user=current_user)

    else:
        return render_template('provinceupdate.html', province=province, bgdecoration='province', user=current_user)


@views.route('/district', methods=['GET', 'POST'])
@login_required
def district():
    provinces = Province.query.order_by(Province.id).all()

    if request.method == 'POST':
        district_name = request.form['name']
        province_id = request.form['province_id']

        if len(district_name) < 2:
            flash('District name is too short!', category='error')
            return render_template('district.html', tooshort=-1, provinces=provinces, bgdecoration='district', user=current_user)
        else:
            record = District(name=district_name, province_id=province_id)

            try:
                db.session.add(record)
                db.session.commit()
                districts = District.query.join(Province).order_by(District.id).all()
                return render_template('district.html', districts=districts, provinces=provinces, bgdecoration='district', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a district with this name!', category='error')
                return render_template('district.html', tooshort=-1, provinces=provinces, bgdecoration='district', user=current_user)

    else:
        districts = District.query.join(Province).order_by(District.id).all()
        return render_template('district.html', districts=districts, provinces=provinces, bgdecoration='district', user=current_user)


@views.route('/districtDelete/<int:id>')
def districtDelete(id):
    if not hasattr(districtDelete, "counter"):
        districtDelete.counter = 0

    if districtDelete.counter > 0:
        return redirect('/district')

    district_to_delete = District.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()

    districtDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + district_to_delete.name + "' district?'", 'Confirm District Deletion')
    districtDelete.counter = 0

    if response == True:
        try:
            db.session.delete(district_to_delete)
            db.session.commit()
            districts = District.query.order_by(District.id).all()
            return render_template('district.html', districts=districts, provinces=provinces, bgdecoration='district', user=current_user)
        except:
            return 'There was a problem deleting that district'
    else:
         return redirect('/district')


@views.route('/districtUpdate/<int:id>', methods=['GET', 'POST'])
def districtUpdate(id):
    district = District.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()

    if request.method == 'POST':
        district.name = request.form['name']
        district.province_id = request.form['province_id']
        districts = District.query.order_by(District.id).all()

        if len(district.name) < 2:
            flash('District name is too short!', category='error')
            return render_template('districtupdate.html', district=district, provinces=provinces, bgdecoration='district', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('district.html', districts=districts, provinces=provinces, bgdecoration='district', user=current_user)
            except:
                db.session.rollback()
                return 'There was an issue updating your district'

    else:
        return render_template('districtupdate.html', district=district, provinces=provinces, bgdecoration='district', user=current_user)


@views.route("/district-filter/<int:province_id>/", methods=["GET"])
def get_request(province_id):
    data = [
        (x[0], x[2]) for x in query_db("district")
        if x[4] == province_id]
    response = make_response(json.dumps(data))
    response.content_type = 'application/json'
    return response


@views.route('/user', methods=['GET', 'POST'])
@login_required
def user():
    if request.method == 'POST':
        user_email = request.form['email']
        first_name = request.form['first_name']
        password = request.form['password']

        if len(user_email) < 2:
            flash('Email is too short!', category='error')
            return render_template('user.html', tooshort=-1, bgdecoration='user', user=current_user)
        else:
            record = User(email=user_email, first_name=first_name, password=password)

            try:
                db.session.add(record)
                db.session.commit()
                users = User.query.order_by(User.email).all()
                return render_template('user.html', users=users, bgdecoration='user', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a user with this email!', category='error')
                return render_template('user.html', tooshort=-1, bgdecoration='user', user=current_user)

    else:
        users = User.query.filter_by(role='A').order_by(User.email).all()
        return render_template('user.html', users=users, bgdecoration='user', user=current_user)


@views.route('/userDelete/<int:id>')
def userDelete(id):
    if not hasattr(userDelete, "counter"):
        userDelete.counter = 0

    if userDelete.counter > 0:
        return redirect('/user')

    user_to_delete = User.query.get_or_404(id)

    userDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + user_to_delete.email + "' user?'", 'Confirm User Deletion')
    userDelete.counter = 0

    if response == True:
        try:
            db.session.delete(user_to_delete)
            db.session.commit()
            users = User.query.filter_by(role='A').order_by(User.email).all()
            return render_template('user.html', users=users, bgdecoration='user', user=current_user)
        except:
            return 'There was a problem deleting that user'
    else:
         return redirect('/user')


@views.route('/userUpdate/<int:id>', methods=['GET', 'POST'])
def userUpdate(id):
    user = User.query.get_or_404(id)

    if request.method == 'POST':
        user.email = request.form['email']
        user.first_name = request.form['first_name']
        if len(request.form['password'])>0:
            user.password = generate_password_hash(request.form['password'], method='sha256')
        users = User.query.filter_by(role='A').order_by(User.email).all()

        if len(user.email) < 2:
            flash('Email is too short!', category='error')
            return render_template('userupdate.html', guser=user, bgdecoration='user', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('user.html', users=users, bgdecoration='user', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a user with this email!', category='error')
                return render_template('user.html', tooshort=-1, bgdecoration='user', user=current_user)

    else:
        return render_template('userupdate.html', guser=user, bgdecoration='user', user=current_user)


@views.route('/store', methods=['GET', 'POST'])
@login_required
def store():
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    if request.method == 'POST':
        name = request.form['name']
        phone_no = request.form['phone_no']
        geoloc = request.form['geoloc']
        province_id = request.form['province_id']
        if province_id == "":
            district_id = ""
        else:
            district_id = request.form['district_id']
        village = request.form['village']

        if len(name) < 2:
            flash('Store name is too short!', category='error')
            return render_template('store.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)
        else:
            record = Store(name=name, phone_no=phone_no, geoloc=geoloc, province_id=province_id, district_id=district_id, village=village)

            try:
                db.session.add(record)
                db.session.commit()
                stores = Store.query.order_by(Store.name).all()
                return render_template('store.html', stores=stores, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a store with this name!', category='error')
                return render_template('store.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)

    else:
        stores = Store.query.order_by(Store.name).all()
        return render_template('store.html', stores=stores, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)


@views.route('/storeDelete/<int:id>')
def storeDelete(id):
    if not hasattr(storeDelete, "counter"):
        storeDelete.counter = 0

    if storeDelete.counter > 0:
        return redirect('/store')

    store_to_delete = Store.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    storeDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + store_to_delete.name + "' store?'", 'Confirm Store Deletion')
    storeDelete.counter = 0

    if response == True:
        try:
            db.session.delete(store_to_delete)
            db.session.commit()
            stores = Store.query.order_by(Store.name).all()
            return render_template('store.html', stores=stores,  provinces=provinces, districts=districts, bgdecoration='store', user=current_user)
        except:
            return 'There was a problem deleting that store'
    else:
         return redirect('/store')


@views.route('/storeUpdate/<int:id>', methods=['GET', 'POST'])
def storeUpdate(id):
    store = Store.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.filter(District.province_id == store.province_id).order_by(District.id).all()

    if request.method == 'POST':
        store.name = request.form['name']
        store.phone_no = request.form['phone_no']
        store.geoloc = request.form['geoloc']
        store.province_id = request.form['province_id']
        if request.form['province_id'] == "":
            store.district_id = ""
        else:
            store.district_id = request.form['district_id']
        store.village = request.form['village']
        stores = Store.query.order_by(Store.name).all()

        if len(store.name) < 2:
            flash('Store name is too short!', category='error')
            return render_template('storeupdate.html', store=store, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('store.html', stores=stores, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a store with this name!', category='error')
                return render_template('store.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)

    else:
        return render_template('storeupdate.html', store=store, provinces=provinces, districts=districts, bgdecoration='store', user=current_user)


@views.route('/distributor', methods=['GET', 'POST'])
@login_required
def distributor():
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    if request.method == 'POST':
        name = request.form['name']
        phone_no = request.form['phone_no']
        geoloc = request.form['geoloc']
        province_id = request.form['province_id']
        if province_id == "":
            district_id = ""
        else:
            district_id = request.form['district_id']
        village = request.form['village']

        if len(name) < 2:
            flash('Distributor name is too short!', category='error')
            return render_template('distributor.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)
        else:
            record = Distributor(name=name, phone_no=phone_no, geoloc=geoloc, province_id=province_id, district_id=district_id, village=village)

            try:
                db.session.add(record)
                db.session.commit()
                distributors = Distributor.query.order_by(Distributor.name).all()
                return render_template('distributor.html', distributors=distributors, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a distributor with this name!', category='error')
                return render_template('distributor.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)

    else:
        distributors = Distributor.query.order_by(Distributor.name).all()
        return render_template('distributor.html', distributors=distributors, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)


@views.route('/distributorDelete/<int:id>')
def distributorDelete(id):
    if not hasattr(distributorDelete, "counter"):
        distributorDelete.counter = 0

    if distributorDelete.counter > 0:
        return redirect('/distributor')

    distributor_to_delete = Distributor.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    distributorDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + distributor_to_delete.name + "' distributor?'", 'Confirm Distributor Deletion')
    distributorDelete.counter = 0

    if response == True:
        try:
            db.session.delete(distributor_to_delete)
            db.session.commit()
            distributors = Distributor.query.order_by(Distributor.name).all()
            return render_template('distributor.html', distributors=distributors, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)
        except:
            return 'There was a problem deleting that distributor'
    else:
         return redirect('/distributor')


@views.route('/distributorUpdate/<int:id>', methods=['GET', 'POST'])
def distributorUpdate(id):
    distributor = Distributor.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.filter(District.province_id == distributor.province_id).order_by(District.id).all()

    if request.method == 'POST':
        distributor.name = request.form['name']
        distributor.phone_no = request.form['phone_no']
        distributor.geoloc = request.form['geoloc']
        distributor.province_id = request.form['province_id']
        if request.form['province_id'] == "":
            distributor.district_id = ""
        else:
            distributor.district_id = request.form['district_id']
        distributor.village = request.form['village']
        distributors = Distributor.query.order_by(Distributor.name).all()

        if len(distributor.name) < 2:
            flash('Distributor name is too short!', category='error')
            return render_template('distributorupdate.html', distributor=distributor, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)
        else:

            try:
                db.session.commit()
                return render_template('distributor.html', distributors=distributors, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a distributor with this name!', category='error')
                return render_template('distributor.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)

    else:
        return render_template('distributorupdate.html', distributor=distributor, provinces=provinces, districts=districts, bgdecoration='distributor', user=current_user)


@views.route('/customer', methods=['GET', 'POST'])
@login_required
def customer():
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    provid = request.args.get('fprovince_id')
    distid = request.args.get('fdistrict_id')

    if request.method == 'POST':
        name = request.form['name']
        phone_no = request.form['phone_no']
        email = request.form['email']
        province_id = request.form['province_id']
        if province_id == "":
            district_id = ""
        else:
            district_id = request.form['district_id']
        village = request.form['village']

        if len(name) < 2:
            flash('Customer name is too short!', category='error')
            return render_template('customer.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)
        else:
            record = Customer(name=name, phone_no=phone_no, email=email, province_id=province_id, district_id=district_id, village=village)

            try:
                db.session.add(record)
                db.session.commit()
                customers = Customer.query.order_by(Customer.name).all()
                return render_template('customer.html', customers=customers, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a customer with this name!', category='error')
                return render_template('customer.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)

    else:
        filterCaption = ""

        if provid == None or provid == "":
            customers = Customer.query.order_by(Customer.name).all()
        else:
            showFilterButton = -1

            if distid == None or distid == "":
                provRecord = Province.query.filter(Province.id == provid).all()
                filterCaption = provRecord[0].name
                customers = Customer.query.filter(Customer.province_id == provid).order_by(Customer.name).all()

            else:
                provRecord = Province.query.filter(Province.id == provid).all()
                filterCaption = provRecord[0].name
                distRecord = District.query.filter(District.id == distid).all()
                filterCaption += ", " + distRecord[0].name
                customers = Customer.query.filter(Customer.province_id == provid, Customer.district_id == distid).order_by(Customer.name).all()

        return render_template('customer.html', customers=customers, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user, filterCaption=filterCaption)


@views.route('/customerDelete/<int:id>')
def customerDelete(id):
    if not hasattr(customerDelete, "counter"):
        customerDelete.counter = 0

    if customerDelete.counter > 0:
        return redirect('/customer')

    customer_to_delete = Customer.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.order_by(District.id).all()

    customerDelete.counter+=1
    response = Confirm("Are you sure you want to delete '" + customer_to_delete.name + "' customer?'", 'Confirm Customer Deletion')
    customerDelete.counter = 0

    if response == True:
        try:
            db.session.delete(customer_to_delete)
            db.session.commit()
            customers = Customer.query.order_by(Customer.name).all()
            return render_template('customer.html', customers=customers, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)
        except:
            return 'There was a problem deleting that customer'
    else:
        return redirect('/customer')


@views.route('/customerUpdate/<int:id>', methods=['GET', 'POST'])
def customerUpdate(id):
    customer = Customer.query.get_or_404(id)
    provinces = Province.query.order_by(Province.id).all()
    districts = District.query.filter(District.province_id == customer.province_id).order_by(District.id).all()

    if request.method == 'POST':
        customer.name = request.form['name']
        customer.phone_no = request.form['phone_no']
        customer.email = request.form['email']
        customer.province_id = request.form['province_id']
        if request.form['province_id'] == "":
            customer.district_id = ""
        else:
            customer.district_id = request.form['district_id']
        customer.village = request.form['village']
        customers = Customer.query.order_by(Customer.name).all()

        if len(customer.name) < 2:
            flash('Customer name is too short!', category='error')
            return render_template('customerupdate.html', customer=customer, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user, disablefilter=-1)
        else:

            try:
                db.session.commit()
                return render_template('customer.html', customers=customers, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)
            except IntegrityError:
                db.session.rollback()
                flash('There\'s already a customer with this name!', category='error')
                return render_template('customer.html', tooshort=-1, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user)

    else:
        return render_template('customerupdate.html', customer=customer, provinces=provinces, districts=districts, bgdecoration='customer', user=current_user, disablefilter=-1)


@views.route('/backup', defaults={'formName': None}, methods=['GET', 'POST'])
@views.route('/backup/<string:formName>', methods=['GET', 'POST'])
def backup(formName):
    root = tkinter.Tk()
    root.wm_attributes("-topmost", 1)
    root.focus()
    root.withdraw()
    dirname = filedialog.askdirectory(parent=root, initialdir="/", title='Please Select a Folder to Save the SQLite Database: csc_data.db')

    if len(dirname) > 0:
        tail = "website/csc_data.db"
        if path.exists(tail):
            #home_dir = pathlib.Path.home()
            current_dir = pathlib.Path.cwd()
            current_dir = os.path.normpath(current_dir)
            path_split = current_dir.split(":")
            path_split = path_split[1].replace("\\","/")
            #url = "file:///Users/Nanthigna/CSC QR Codes/website/csc_data.db"
            url= "file://" + path_split + "/" + tail

            try:
                wget.download(url,out = dirname)
                flash('Backup of "csc_data.db" database completed successfully!', category='success')

            except:
                return 'There was a problem when backup the database!'

        else:
            print("File does not exists!")

    else:
        pass

    root.destroy()

    if formName == None:
        return render_template("home.html", user=current_user)
    else:
        formName = "/" + formName

    return redirect(formName)


@views.route('/restore', defaults={'formName': None}, methods=['POST'])
@views.route('/restore/<string:formName>', methods=['POST'])
def restore(formName):
    target = APP_ROOT

    for file in request.files.getlist("file"):
        filename = file.filename
        if filename != "csc_data.db":
            flash("Restore failed - File is not valid!", category='error')
        else:
            destination = "/".join([target, filename])
            try:
                file.save(destination)
                flash('Restore of "csc_data.db" database completed successfully!', category='success')
            except:
                return 'There was a problem when restoring the database!'

    if formName == None:
        return render_template("home.html", user=current_user)
    else:
        formName = "/" + formName

    return redirect(formName)


@views.route('/importCustomersFromXL', defaults={'formName': None}, methods=['POST'])
@views.route('/importCustomersFromXL/<string:formName>', methods=['POST'])
def importCustomersFromXL(formName):
    target = APP_ROOT

    for file in request.files.getlist("file"):
        filename = file.filename
        if filename != "Customers.xlsm":
            flash('Import "Customers.xlsm" datasheet failed - File is not valid!', category='error')
        else:
            file_path  = "/datasheets/".join([target, filename])
            file_path =file_path.replace("\\","/")
            try:
                file.save(file_path )
            except:
                return 'There was a problem uploading "Customers.xlsm" file!'

    db_path = "/".join([target, "csc_data.db"])
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    wb = load_workbook(file_path)
    ws = wb["CustomersDS"]

    Customers = '''INSERT INTO customer(name, phone_no, email, province_id, district_id, village, reg_date) VALUES (?,?,?,?,?,?,?)'''
    for row in ws.iter_rows(min_row=2, min_col=2, max_col=8, max_row=ws.max_row):
        cust=[cell.value for cell in row]
        cur.execute(Customers, cust)

    conn.commit()
    conn.close()

    flash('Uploading customers data from "Customers.xlsm" completed successfully!', category='success')

    if formName == None:
        return render_template("home.html", user=current_user)
    else:
        formName = "/" + formName

    return redirect(formName)


def Confirm(message, title):
    root = tkinter.Tk()
    root.wm_attributes("-topmost", 1)
    root.focus()
    root.withdraw()

    #w = tk.Toplevel(takefocus=True)
    response = tkinter.messagebox.askokcancel(title, message, parent=root, default = "cancel")

    root.destroy()

    return response
